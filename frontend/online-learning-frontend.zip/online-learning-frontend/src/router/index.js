import { createRouter, createWebHistory } from 'vue-router'
import Login from '../views/AuthView.vue'
import Dashboard from '../views/Dashboard.vue'
import TeacherDashboard from '../components/TeacherDashboard'
import StudentDashboard from '../components/StudentDashboard'
import CoursePage from '../views/CoursePage.vue'

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: Login },
  { path: '/dashboard', component: Dashboard, meta: { requiresAuth: true } },
  { path: '/teacher-dashboard', component: TeacherDashboard, meta: { requiresAuth: true } },
  { path: '/student-dashboard', component: StudentDashboard, meta: { requiresAuth: true } },
  {
    path: '/course/:id',
    name: 'CoursePage',
    component: CoursePage,
    meta: { requiresAuth: true },
    props: route => ({ id: Number(route.params.id) })
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('access_token')
  if (to.meta.requiresAuth && !token) {
    next('/login')
  } else {
    next()
  }
})

export default router
