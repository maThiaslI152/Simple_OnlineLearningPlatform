import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import api from './axios'

const token = localStorage.getItem('accessToken')
if (token) {
  api.defaults.headers.common['Authorization'] = `Bearer ${token}`
  store.dispatch('auth/fetchUser').catch(() => {
    // If token invalid, auto logout using store action:
    store.dispatch('auth/logout')
    router.push('/login')
  })
}

createApp(App)
  .use(store)
  .use(router)
  .mount('#app')
